package fatecpg.br.edu.service;

public record Comment(int postId, int id, String name, String email, String body) {}

